# Back-compat shim — moved to urirun_node.manage (Phase 5 node extraction).
import sys as _sys
from urirun_node import manage as _moved
_sys.modules[__name__] = _moved
